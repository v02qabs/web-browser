javac -cp ./:swt4.jar: Main.java
