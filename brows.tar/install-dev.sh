sudo apt install -y libswt-gtk-4-jni libswt-gtk-4-java libswt-webkit-gtk-4-jni
