java -cp ./:swt4.jar: Main 
